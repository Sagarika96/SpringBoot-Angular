package org.springframework.security.config.annotation.web.configuration.basic.auth;

public class SpringSecurityConfigurationBasicAuth {

}
