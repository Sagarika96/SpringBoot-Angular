package com.webservices.restfulwebservices.helloworld;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="*")
@RestController
public class HelloWorldController {

	
	//GET
	//URI- /hello-world
	//method- "Hello World"
	

	
	@GetMapping("/hello-world")
	public String hello()
	{
		
		
		return "Hello World";
	}
	

	@GetMapping(path="/hello-world-bean")
	public HelloBean hellobean()
	{
		
		
		return new HelloBean("Hello World changed");
	}
	
	@GetMapping(path="/hello-world/path-variable/{name}")
	public HelloBean hellobeanpath(@PathVariable String name)
	{
		
		
		return new HelloBean(String.format("Hello World, %s",name));
	}
	
	
}
